import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.testing.decorators import image_comparison

@image_comparison(baseline_images=['Plot_with_Style1'],extensions=['png'])
def test_generate_plot_with_style1():

    # Write your functionality below


@image_comparison(baseline_images=['Plot_with_Style2'],extensions=['png'])
def test_generate_plot_with_style2():

    # Write your functionality below


@image_comparison(baseline_images=['Plot_with_Style3'],extensions=['png'])
def test_generate_plot_with_style3():

    # Write your functionality below
  
